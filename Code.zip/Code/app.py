import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
import pandas as pd
import feature
import sqlite3

app = Flask(__name__)
model = pickle.load(open('Phising_website.pkl','rb'))

ds= pd.read_csv("data/dataset_website.csv")
x=ds.iloc[:,1:31].values
y=ds.iloc[:,-1].values
print(x,y)
y=ds.iloc[:,-1].values
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=0)

from sklearn.tree import DecisionTreeClassifier
dt=DecisionTreeClassifier()
dt.fit(x_train,y_train)
y_pred6=dt.predict(x_test)

from sklearn.metrics import accuracy_score
score = round((accuracy_score(y_test,y_pred6) * 100),2)

print(score)


@app.route('/')
def home():
    return render_template('home.html')

@app.route('/logon')
def logon():
	return render_template('signup.html')

@app.route('/login')
def login():
	return render_template('signin.html')





@app.route('/predict')
def predict():
    return render_template('index.html')

@app.route('/y_predict', methods=['POST'])
def y_predict():
    url = request.form['URL']
    checkprediction = feature.main(url)
    prediction = dt.predict(checkprediction)
    
    print(prediction)
    output=prediction[0]
    if(output==1):
        import webbrowser
        pred="The Result : You are safe!!  This is a legitimate Website."
        webbrowser.open(url, new=2)
        return render_template('index.html',bns=pred, val = score)
    
    else:
        pred="The Result : You are on the wrong site. Be cautious!"        
        return render_template('index.html',ans=pred, val = score)

      
 
if __name__ == '__main__':
    app.run(host='127.0.0.1', debug=True)
    